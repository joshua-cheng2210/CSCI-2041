include Ast

module Parser = Parser
module Lexer = Lexer

let parse (s : string) : expression =
  let lexbuf = Lexing.from_string s in
  let ast = Parser.expression_eof Lexer.token lexbuf in
     ast

let string_of_declaration = String_of.string_of_declaration

let empty = []
let singleton x y = [(x,y)]

let merge s1 s2 =
  let rec merge_helper s1 s2 =
    match s1, s2 with
    | [], _ -> Some s2 (* If s1 is empty, return s2 *)
    | (k1, v1) :: tl1, _ ->
        if List.exists (fun (k2, _) -> k1 = k2) s2 then
          None (* Conflicting keys found, return None indicating merge failure *)
        else
          match merge_helper tl1 s2 with
          | Some merged -> Some ((k1, v1) :: merged) (* Add key-value pair to merged result *)
          | None -> None
  in
  match merge_helper s1 s2 with
  | Some merged -> Some merged
  | None -> (* Check if s1 was initially empty *)
      if s1 = [] then Some s2
      else None (* Indicates failure due to a conflict *)

let is_variable x variables =
  List.exists (fun var -> var = x) variables

let rec match_expression variables pattern expression =
  match pattern with
    | Identifier x -> if is_variable x variables then (* Todo: fix test for variables: the string "x" is not necessarily the only variable and it might not always be a variable either *)
        (* if x is a variable: *)
        Some (singleton x expression)
        else
        (* if x is a constant: *)
        (if pattern = expression then Some empty else None)
    | Application (p1, p2) -> (* x has to be an application too, otherwise return None *)
        (match expression with
            | Application (e1, e2) ->
                (* We recursively match the sub-expressions.
                    This part is much easier to write if e2 is an expression (and it is for this particular ast),
                    because it's so symmetrical *)
                (match match_expression variables p1 e1, match_expression variables p2 e2 with
                | Some s1, Some s2 -> merge s2 s1
                | _ -> None)
            | _ -> None)
    | _ -> None

let find x s =
  try Some (List.assoc x s)
  with Not_found -> None

(* let rec substitute variables s e = match e with   ****IGNORE THIS UNLESS YOU'D LIKE TO FIX IT 
    | Identifier id -> if List.mem id variables then (match find id s with Some e -> e | None -> e)
      else e
    | Application (e1, e2) -> Application (substitute variables s e1, List.map (fun expr -> substitute variables s e2))
    | _ -> e *)

let extract_rhs (eq : equality) : expression =
  match eq with 
  | Equality(_, rhs) -> rhs

let extract_lhs (eq : equality) : expression =
  match eq with 
  | Equality(lhs, _) -> lhs

let rec attempt_rewrite variables eq expression =
  let rhs = extract_rhs(eq) in
  let lhs = extract_lhs(eq) in
  match match_expression variables lhs expression with
    | Some subst -> Some (applySubst variables subst rhs)
    | None -> 
      (match expression with
        | Application (fn, arg) -> 
            (match attempt_rewrite variables eq arg with
             | Some e2' -> Some (Application (fn, e2'))
             | None ->
                 match attempt_rewrite variables eq fn with
                 | Some e1' -> Some (Application (e1', arg))
                 | None -> None)
        | Identifier _ -> None
        | _ -> None)  (* Catch-all case *)
and applySubst vars subst expr = 
  match expr with 
  | Identifier id -> 
    (match find id subst with
    | Some value -> value
    | None -> expr) (* If the identifier isn't in the substitution, return the original expression *)
  | Application (e1, e2) ->
    Application (applySubst vars subst e1, applySubst vars subst e2)
  | _ -> expr

let rec perform_step rules expression = match rules with
  | (variables, nm, eq) :: _ :: rest -> (match attempt_rewrite variables eq expression with
      | Some e -> Some (nm, e)
      | _ -> perform_step rest expression)
  | _ -> None

let rec perform_steps rules expression = match perform_step rules expression with
  | Some (nm, e) -> (nm, e) :: perform_steps [] e
  | None -> []

  let rec prove rules lhs rhs
  = String_of.string_of_expression lhs :: 
    (match perform_steps rules lhs with
     | (nm, e) :: _ -> (" = { " ^ nm ^ " }") :: prove rules e rhs
     | [] -> if lhs = rhs then [] else " = { ??? }" :: [String_of.string_of_expression rhs])
     
     let rec prover rules declarations =
      match declarations with
         | ProofDeclaration (nm, vars, Equality (lhs,rhs), None) :: rest
            -> (* no hint, so let's prove this *)
               prove rules lhs rhs :: prover ((vars,nm,lhs,rhs)::rules) rest
         | ProofDeclaration (nm, vars, Equality (lhs,rhs), _) :: rest
            -> (* we got a hint so we simply assume the statement *)
               prover ((vars,nm,lhs,rhs)::rules) rest
         | _ :: rest -> prover rules rest
         | [] -> []
   let prover_main decls =
      prover [] decls |>
      List.map (String.concat "\n") |>
      String.concat "\n\n" |>
      print_endline 